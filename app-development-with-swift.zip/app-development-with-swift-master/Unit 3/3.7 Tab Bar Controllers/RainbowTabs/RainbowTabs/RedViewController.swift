//
//  RedViewController.swift
//  RainbowTabs
//
//  Created by Michael Westerby on 24/04/2020.
//  Copyright © 2020 Michael Westerby. All rights reserved.
//

import UIKit

class RedViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        tabBarItem.badgeValue = "!"
    }


}

