import UIKit

// Exercise - Optionals

let userInputAge: String = "34"

if let userAge = Int(userInputAge) {
    print(userAge)
}
